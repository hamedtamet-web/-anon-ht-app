const ADS_CONFIG = {
    publisherId: 'ca-pub-9442350195298931',
    slots: {
        feed:    '1551654347',
        display: '5299327669'
    },
    feedFrequency: 5,
    adsterra: {
        socialBar: 'https://assistedtogether.com/9f/c4/e2/9fc4e21c71c764da2d80fd465e66a454.js',
        bannerKey:  'f36658d42131ec282e9ddb99816dbca4',
        bannerSrc:  'https://assistedtogether.com/f36658d42131ec282e9ddb99816dbca4/invoke.js'
    }
};

function shouldShowAds(userData) {
    if (!userData) return true;
    if (!userData.isPremium) return true;
    if (!userData.premiumUntil) return true;
    const until = userData.premiumUntil.toDate
        ? userData.premiumUntil.toDate()
        : new Date(userData.premiumUntil);
    if (until > new Date()) return false;
    return true;
}

function loadAdsterraSocialBar() {
    if (document.querySelector(`script[src="${ADS_CONFIG.adsterra.socialBar}"]`)) return;
    const s = document.createElement('script');
    s.src = ADS_CONFIG.adsterra.socialBar;
    s.async = true;
    document.body.appendChild(s);
}

function createAdsterraBanner() {
    const wrapper = document.createElement('div');
    wrapper.style.cssText = `
        display:flex;
        justify-content:center;
        align-items:center;
        margin:10px 0;
        background:#0d0d0d;
        border:1px solid rgba(255,255,255,0.06);
        border-radius:18px;
        padding:10px;
        overflow:hidden;
    `;
    const s1 = document.createElement('script');
    s1.textContent = `atOptions={'key':'${ADS_CONFIG.adsterra.bannerKey}','format':'iframe','height':50,'width':320,'params':{}}`;
    const s2 = document.createElement('script');
    s2.src = ADS_CONFIG.adsterra.bannerSrc;
    wrapper.appendChild(s1);
    wrapper.appendChild(s2);
    return wrapper;
}

const AdsManager = {

    init: function(userData) {
        if (this._initialized) return;
        this._initialized = true;
        window._showAds = shouldShowAds(userData);
        if (window._showAds) {
            loadAdsterraSocialBar();
            this.injectStaticAd('AD_LOGIN_BOTTOM');
            this.injectStaticAd('AD_PROFILE_TOP');
            const topBanner = document.getElementById('topAdBanner');
            if (topBanner) {
                topBanner.style.display = 'flex';
                topBanner.appendChild(createAdsterraBanner());
            }
        }
    },

    injectAds: function(feedEl) {
        if (window._showAds === false) return;
        // إعلان ثابت في أول الفيد
        feedEl.insertBefore(createAdsterraBanner(), feedEl.firstChild);
        const cards = feedEl.querySelectorAll('.ans-card, .ask-card, .shout-inbox-card, .sada-card');
        cards.forEach((card, i) => {
            const pos = i + 1;
            if (pos % 10 === 0) {
                card.after(createAdsterraBanner());
                const wrapper = document.createElement('div');
                wrapper.style.cssText = `
                    background:#0d0d0d;
                    border:1px solid rgba(255,255,255,0.06);
                    border-radius:18px;
                    padding:12px;
                    margin-bottom:12px;
                    width:100%;
                    overflow:hidden;
                    display:flex;
                    justify-content:center;
                `;
                wrapper.innerHTML = `
                    <ins class="adsbygoogle"
                         style="display:block;width:100%;max-width:320px;"
                         data-ad-client="${ADS_CONFIG.publisherId}"
                         data-ad-slot="${ADS_CONFIG.slots.feed}"
                         data-ad-format="auto"
                         data-full-width-responsive="true"></ins>`;
                card.after(wrapper);
                setTimeout(() => {
                    try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch(e) {}
                }, 150);
            } else if (pos % 5 === 0) {
                card.after(createAdsterraBanner());
            }
        });
    },

    injectStaticAd: function(containerId) {
        if (window._showAds === false) return;
        const el = document.getElementById(containerId);
        if (!el) return;
        el.innerHTML = `
            <ins class="adsbygoogle"
                 style="display:block;width:100%;"
                 data-ad-client="${ADS_CONFIG.publisherId}"
                 data-ad-slot="${ADS_CONFIG.slots.display}"
                 data-ad-format="auto"
                 data-full-width-responsive="true"></ins>`;
        setTimeout(() => {
            try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch(e) {}
        }, 100);
    }
};